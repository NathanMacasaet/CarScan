CarScan 3D Scanner

Files:
- CarScanApp.swift
- ContentView.swift
- ARViewContainer.swift
- ScanManager.swift
- ModelViewer.swift

Setup:
1. Open your existing CarScan Xcode project.
2. Replace the contents of the matching Swift files with these files.
3. Do NOT add ScannedCar.usdz to the project. The app creates the file after a scan.
4. Add Privacy - Camera Usage Description in Target > Info.
5. Run on a physical LiDAR-equipped iPhone.
6. Tap Start Scan.
7. Slowly scan all sides of the car.
8. Tap Finish & Save.
9. The saved 3D model opens in the viewer.

Note:
The current prototype captures the LiDAR surface mesh and displays it as a 3D model. It does not automatically detect dents/scratches yet.