import SwiftUI
import RealityKit
import ARKit

struct ARViewContainer: UIViewRepresentable {
    @Binding var isScanning: Bool

    func makeCoordinator() -> Coordinator {
        Coordinator()
    }

    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        let configuration = ARWorldTrackingConfiguration()

        guard ARWorldTrackingConfiguration.supportsSceneReconstruction(.mesh) else {
            print("LiDAR scene reconstruction is not available on this device.")
            return arView
        }

        configuration.sceneReconstruction = .meshWithClassification
        configuration.environmentTexturing = .automatic

        arView.session.delegate = context.coordinator
        context.coordinator.isScanning = isScanning
        arView.session.run(configuration)

        return arView
    }

    func updateUIView(_ uiView: ARView, context: Context) {
        context.coordinator.isScanning = isScanning
    }

    static func dismantleUIView(_ uiView: ARView, coordinator: Coordinator) {
        uiView.session.pause()
    }

    final class Coordinator: NSObject, ARSessionDelegate {
        var isScanning = false

        func session(_ session: ARSession, didAdd anchors: [ARAnchor]) {
            guard isScanning else { return }
            for anchor in anchors {
                if let meshAnchor = anchor as? ARMeshAnchor {
                    ScanManager.shared.addMeshAnchor(meshAnchor)
                }
            }
        }

        func session(_ session: ARSession, didUpdate anchors: [ARAnchor]) {
            guard isScanning else { return }
            for anchor in anchors {
                if let meshAnchor = anchor as? ARMeshAnchor {
                    ScanManager.shared.updateMeshAnchor(meshAnchor)
                }
            }
        }

        func session(_ session: ARSession, didRemove anchors: [ARAnchor]) {
            guard isScanning else { return }
            for anchor in anchors {
                if let meshAnchor = anchor as? ARMeshAnchor {
                    ScanManager.shared.removeMeshAnchor(meshAnchor)
                }
            }
        }
    }
}